import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

import {
  assembleConversationControlContext,
  buildDialogueState,
  createResponsePlan,
  interpretTurnDeterministically,
  type OrdinaryHandoffBoundary,
  type ResponseAction,
  type ResponsePlan,
} from "../conversation-os/control";
import { determineConversationState } from "../conversation-os/state";
import type { CommittedAssistantMove, ConversationMessage } from "../conversation-os/types";
import { createChatReply } from "../services/ai/chatOrchestrationService";
import { validateResponsePlanOutput } from "../services/ai/responsePlanValidator";

const uncertainBoundary = (
  userBoundaries: OrdinaryHandoffBoundary["userBoundaries"] = []
): OrdinaryHandoffBoundary => ({
  source: "hill_helping",
  applicability: "uncertain",
  userBoundaries,
  evidence: ["The Hill decision has insufficient evidence to select a helping goal or technique."],
});

const build = ({
  userMessage,
  recentMessages = [],
  boundary = uncertainBoundary(),
}: {
  userMessage: string;
  recentMessages?: ConversationMessage[];
  boundary?: OrdinaryHandoffBoundary | null;
}) => {
  const conversationState = determineConversationState({ currentUserMessage: userMessage, recentMessages });
  const context = assembleConversationControlContext({
    conversationId: "hill-batch1-5-check",
    currentTurnId: `turn-${recentMessages.length + 1}`,
    userMessage,
    recentMessages,
    conversationState,
  });
  const interpretation = interpretTurnDeterministically(context);
  const dialogueState = buildDialogueState(context, interpretation);
  const responsePlan = createResponsePlan({
    context,
    interpretation,
    dialogueState,
    ordinaryHandoffBoundary: boundary,
    clinicalAdviceProvider: ({ need }) => ({
      strategy: "test-legacy-compat",
      intent: need,
      questionFunction: "none",
      toneConstraints: [],
      interventionBoundaries: [],
      evidence: ["test"],
    }),
  });
  return { context, interpretation, dialogueState, responsePlan };
};

const committedMove = ({
  purpose,
  question = false,
  sourceTurnId,
}: {
  purpose: ResponseAction[];
  question?: boolean;
  sourceTurnId: string;
}): CommittedAssistantMove => ({
  purpose,
  claims: [],
  assumptions: [],
  questionOrRequest: question ? { kind: "question" } : null,
  expectedUserContribution: question ? "answer" : "none",
  userBurden: question ? "low" : "none",
  sourceTurnId,
  evidence: ["Committed only after validation."],
});

const previousTopic: ConversationMessage[] = [
  { id: "topic-user", role: "user", content: "今天开会时我一直没说上话。" },
  {
    id: "topic-assistant",
    role: "assistant",
    content: "你刚才说的是开会时一直没说上话。",
    committedAssistantMove: committedMove({
      purpose: ["acknowledge_without_psychologizing"],
      sourceTurnId: "topic-assistant",
    }),
  },
];

const explicitAnswerFrame: ConversationMessage[] = [
  { id: "frame-user", role: "user", content: "我想先选一个方向。" },
  {
    id: "frame-assistant",
    role: "assistant",
    content: "请回编号：1. 先把事情说清楚；2. 先想下一步。",
    committedAssistantMove: committedMove({
      purpose: ["take_light_topic_initiative"],
      question: true,
      sourceTurnId: "frame-assistant",
    }),
  },
];

const pairedForms = [
  "1", "2", "3", "0", "嗯", "好", "行", "是", "不", "A",
  "？", "。", "…", "🙂", "👍", "啊", "哦", "哈", "7", "9",
];

const handoffAction = (plan: ResponsePlan) => plan.responseActions.find((action) => [
  "invite_low_pressure_calibration",
  "continue_established_frame",
  "continue_established_thread",
  "offer_neutral_conversation_entry",
].includes(action));

const run = async () => {
  for (const form of pairedForms) {
    const withoutContext = build({ userMessage: form }).responsePlan;
    const withTopic = build({ userMessage: form, recentMessages: previousTopic }).responsePlan;
    assert.equal(handoffAction(withoutContext), "invite_low_pressure_calibration", `${form}: no-context path`);
    assert.equal(handoffAction(withTopic), "continue_established_thread", `${form}: established-topic path`);
    assert.equal(withoutContext.behaviorSource, "ordinary_conversation");
    assert.equal(withTopic.behaviorSource, "ordinary_conversation");
  }

  const answerFrame = build({ userMessage: "2", recentMessages: explicitAnswerFrame }).responsePlan;
  assert.equal(handoffAction(answerFrame), "continue_established_frame");
  assert.equal(answerFrame.questionPolicy.mode, "none");

  const directAnswer = build({ userMessage: "你是AI吗？" }).responsePlan;
  assert(directAnswer.responseActions.includes("answer_directly"));
  assert.equal(handoffAction(directAnswer), undefined);

  const pause = build({ userMessage: "先别问了" }).responsePlan;
  assert.deepEqual(pause.responseActions, ["respect_pause"]);
  assert.equal(pause.questionPolicy.mode, "none");

  const emotion = build({ userMessage: "我今天很难受" }).responsePlan;
  assert(emotion.responseActions.includes("offer_emotional_support"));
  assert.equal(handoffAction(emotion), undefined);

  const action = build({ userMessage: "帮我想想下一步怎么办" }).responsePlan;
  assert(action.responseActions.includes("offer_action_support"));
  assert.equal(handoffAction(action), undefined);

  const repair = build({
    userMessage: "不是这个意思，你理解错了",
    recentMessages: [{ id: "repair-assistant", role: "assistant", content: "你今天很开心。" }],
  }).responsePlan;
  assert(repair.responseActions.includes("repair_previous_wording"));
  assert.equal(handoffAction(repair), undefined);

  const noQuestions = build({
    userMessage: "1",
    boundary: uncertainBoundary(["no_questions"]),
  }).responsePlan;
  assert.equal(handoffAction(noQuestions), "offer_neutral_conversation_entry");
  assert.equal(noQuestions.questionPolicy.mode, "none");

  const multiTurnActions: Array<ResponseAction | undefined> = [];
  const multiTurnHistory: ConversationMessage[] = [];
  for (const [index, userMessage] of ["1", "2", "3"].entries()) {
    const plan = build({ userMessage, recentMessages: multiTurnHistory }).responsePlan;
    const selected = handoffAction(plan);
    multiTurnActions.push(selected);
    assert.notEqual(selected, "acknowledge_without_psychologizing");
    multiTurnHistory.push({ id: `multi-user-${index + 1}`, role: "user", content: userMessage });
    multiTurnHistory.push({
      id: `multi-assistant-${index + 1}`,
      role: "assistant",
      content: selected === "invite_low_pressure_calibration"
        ? "我还不确定该怎么接；你希望我先等你继续，还是给一个轻一点的开头？"
        : "我先起个头：今天最普通的一小段，也可以从那里说。",
      committedAssistantMove: committedMove({
        purpose: selected ? [selected] : [],
        question: selected === "invite_low_pressure_calibration",
        sourceTurnId: `multi-assistant-${index + 1}`,
      }),
    });
  }
  assert.deepEqual(multiTurnActions, [
    "invite_low_pressure_calibration",
    "offer_neutral_conversation_entry",
    "invite_low_pressure_calibration",
  ]);
  assert.notEqual(multiTurnActions[0], multiTurnActions[1]);
  assert.notEqual(multiTurnActions[1], multiTurnActions[2]);

  const invitePlan = build({ userMessage: "1" }).responsePlan;
  assert.equal(validateResponsePlanOutput({ plan: invitePlan, reply: "收到。" }).passed, false);
  assert.equal(
    validateResponsePlanOutput({
      plan: invitePlan,
      reply: "我还不确定该怎么接；你想让我先等你继续，还是给一个轻一点的开头？",
    }).passed,
    true
  );
  assert.equal(
    validateResponsePlanOutput({ plan: invitePlan, reply: "这个是什么意思？" }).passed,
    false
  );
  assert.equal(
    validateResponsePlanOutput({
      plan: noQuestions,
      reply: "我先起个头：今天最普通的一小段，也可以从那里说。",
    }).passed,
    true
  );

  const previousProvider = process.env.AI_PROVIDER;
  const previousInterpreter = process.env.CONVERSATION_OS_INTERPRETER_MODEL_ENABLED;
  process.env.AI_PROVIDER = "mock";
  process.env.CONVERSATION_OS_INTERPRETER_MODEL_ENABLED = "false";
  try {
    const disabled = await createChatReply({
      conversationId: "batch1-5-disabled",
      currentTurnId: "batch1-5-disabled-turn",
      userMessage: "1",
      recentMessages: [],
      helpingShadowEnabled: true,
      helpingOrdinaryHandoffEnabled: false,
    });
    assert(disabled.controlTrace?.responsePlan.responseActions.includes("acknowledge_without_psychologizing"));
    const enabled = await createChatReply({
      conversationId: "batch1-5-enabled",
      currentTurnId: "batch1-5-enabled-turn",
      userMessage: "1",
      recentMessages: [],
      helpingShadowEnabled: true,
      helpingOrdinaryHandoffEnabled: true,
    });
    assert(enabled.controlTrace?.responsePlan.responseActions.includes("invite_low_pressure_calibration"));
    assert.equal(enabled.controlTrace?.responsePlan.behaviorSource, "ordinary_conversation");
    assert.equal(JSON.stringify(enabled.controlTrace?.responsePlan).includes("primarySkill"), false);
    assert.equal(JSON.stringify(enabled.controlTrace?.responsePlan).includes("primaryGoal"), false);

    let safetyProviderCalls = 0;
    const safety = await createChatReply({
      conversationId: "batch1-5-safety",
      currentTurnId: "batch1-5-safety-turn",
      userMessage: "我现在想伤害自己",
      recentMessages: [],
      helpingOrdinaryHandoffEnabled: true,
      helpingDecisionProvider: async () => {
        safetyProviderCalls += 1;
        throw new Error("Safety must not call ordinary Helping.");
      },
    });
    assert.equal(safety.finalSource, "safety");
    assert.equal(safetyProviderCalls, 0);
  } finally {
    if (previousProvider === undefined) delete process.env.AI_PROVIDER;
    else process.env.AI_PROVIDER = previousProvider;
    if (previousInterpreter === undefined) delete process.env.CONVERSATION_OS_INTERPRETER_MODEL_ENABLED;
    else process.env.CONVERSATION_OS_INTERPRETER_MODEL_ENABLED = previousInterpreter;
  }

  const helpingSource = readFileSync("services/helping/hillHelpingDecisionService.ts", "utf8");
  const plannerSource = readFileSync("conversation-os/control/responsePlanner.ts", "utf8");
  const surfaceSource = readFileSync("services/ai/promptBuilder.ts", "utf8");
  assert(!helpingSource.includes("invite_low_pressure_calibration"));
  assert(!helpingSource.includes("offer_neutral_conversation_entry"));
  assert(!plannerSource.includes("HillGoalFamily"));
  assert(!plannerSource.includes("HillSkill"));
  assert(!surfaceSource.includes("HillGoalFamily"));
  assert(!surfaceSource.includes("HillSkill"));

  console.log(JSON.stringify({
    frozenBatch0NumericRegressionTurns: 6,
    sameFormDifferentContextPairs: pairedForms.length,
    pairedTurnsChecked: pairedForms.length * 2,
    heldOutForms: pairedForms.slice(-5),
    multiTurnFunctionalActions: multiTurnActions,
    hardGates: {
      safety: true,
      directAnswerAndGrounding: true,
      pause: true,
      answerFrame: true,
      currentTopic: true,
      emotionalSupport: true,
      actionSupport: true,
      repair: true,
    },
    ownership: {
      behaviorSource: "ordinary_conversation",
      helpingSelectsOrdinaryAction: false,
      plannerSelectsHillGoalOrSkill: false,
      committedHelpingMoveWritten: false,
    },
  }, null, 2));
};

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
