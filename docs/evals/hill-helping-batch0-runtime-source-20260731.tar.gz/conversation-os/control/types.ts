import type { ConversationInteractionSignals } from "../state";
import type { CommittedAssistantMove, ConversationMessage } from "../types";

export type DialogueAct =
  | "share" | "answer" | "ask_information" | "ask_identity" | "ask_capability"
  | "ask_definition" | "challenge_contradiction" | "correct_assistant" | "yield_initiative"
  | "request_pause" | "end_conversation" | "seek_emotional_support" | "request_action_support" | "acknowledge";

export type GroundingReference =
  | "identity" | "ai_identity" | "clinician_identity" | "body" | "body_metaphor"
  | "physical_presence" | "physical_presence_metaphor"
  | "voice_input" | "voice_output" | "vision" | "hearing"
  | "time" | "memory" | "previous_wording" | "none";

export type DirectQuestionKind =
  | "identity" | "ai_identity" | "clinician_identity"
  | "body_capability" | "voice_input" | "voice_output" | "perception_capability"
  | "time_capability" | "memory_capability" | "definition" | "reason_or_contradiction" | "other";

export type DirectQuestion = {
  text: string;
  kind: DirectQuestionKind;
  subject?: string;
  evidence: string[];
};

export type ChallengedProposition = {
  id: string;
  text: string;
  sourceTurnId: string;
  groundingReference?: GroundingReference;
  status: "rejected";
};

export type StillOpenUserIntent = {
  kind: "no_topic";
  sourceTurnId: string;
  text: string;
};

export type CorrectionSignal = {
  targetTurnId: string;
  correctionType: "irrelevant_answer" | "wrong_assumption" | "misunderstanding";
  challengedPropositions: ChallengedProposition[];
  stillOpenUserIntent: StillOpenUserIntent | null;
  evidence: string[];
};

export type ResponseRelationKind =
  | "requests_answer"
  | "answers_previous_move"
  | "repairs_previous_move"
  | "continues_active_thread"
  | "opens_new_thread"
  | "yields_initiative"
  | "shares_initiative"
  | "requests_pause"
  | "requests_action_support"
  | "shares_distress"
  | "acknowledges_previous_move";

export type RelationalInterpretationCandidate = {
  relation: ResponseRelationKind;
  confidence: number;
  targetTurnId?: string;
  evidence: string[];
};

export type ContentMeaning = {
  literalText: string;
  semanticEvidence: ConversationControlContext["semanticEvidence"];
  explicitPropositions: Array<{
    id: string;
    text: string;
    sourceTurnId: string;
    confidence: number;
    evidence: string[];
  }>;
  directQuestions: DirectQuestion[];
  contentAvailabilityEvidence: string[];
  affectEvidence: string[];
};

export type TurnStateUpdate = {
  commonGround: Array<{
    propositionId: string;
    proposition: string;
    operation: "confirm" | "hypothesize" | "reject";
    subject: "user" | "assistant" | "system" | "conversation";
    speaker: "user" | "assistant" | "system";
    epistemicStatus:
      | "asserted_by_user"
      | "assistant_hypothesis"
      | "system_truth"
      | "selected_memory"
      | "rejected_by_user";
    sourceTurnId: string;
    confidence: number;
    evidence: string[];
  }>;
  obligationChanges: Array<{
    operation: "open";
    sourceTurnId: string;
    targetProposition: string;
    evidence: string[];
  }>;
  initiativeProposal: "user" | "assistant" | "shared" | "paused";
  activeThreadProposal: {
    sourceTurnId: string;
    relation: "continue" | "open" | "pause" | "close";
    evidence: string[];
  } | null;
  repairProposal: {
    targetTurnId: string;
    rejectedPropositionIds: string[];
    evidence: string[];
  } | null;
};

export type RelationalTurnInterpretation = {
  id: string;
  contentMeaning: ContentMeaning;
  responseRelation: RelationalInterpretationCandidate;
  stateUpdate: TurnStateUpdate;
  confidence: number;
  evidence: string[];
};

export type TurnInterpretation = {
  contentMeaning: ContentMeaning;
  responseRelation: {
    candidates: RelationalInterpretationCandidate[];
    ambiguous: boolean;
  };
  stateUpdate: TurnStateUpdate;
  interpretations: RelationalTurnInterpretation[];
  /**
   * Compatibility evidence only. Dialogue State and Response Planner must not
   * use this field to select a response strategy.
   */
  literalMeaning: string;
  primaryDialogueAct: DialogueAct;
  secondarySignals: DialogueAct[];
  directQuestions: DirectQuestion[];
  interaction: ConversationInteractionSignals;
  repairSignal: boolean;
  correction: CorrectionSignal | null;
  groundingReference: GroundingReference;
  confidence: number;
  evidenceSources: Array<"current_user_message" | "adjacent_turn" | "deterministic_boundary" | "model_interpretation">;
  notes: string[];
};

export type AssistantGrounding = {
  source: "assistant_grounding_v2";
  availableFacts: {
    identity: { name: "慢聊小记"; kind: "AI聊天助手"; isAi: true; isClinician: false; roleBoundary: string };
    modalities: { textInput: true; textOutput: true; voiceInput: false; voiceOutput: false; vision: false; hearing: false };
    embodiment: { hasBody: false; canSit: false; canSleep: false; canHug: false; canTouch: false; boundary: string };
    capabilities: { currentTimeWithoutContext: false; memory: string };
  };
  prohibitedClaims: string[];
};

export type ConversationControlContext = {
  conversationId: string;
  currentTurnId: string;
  currentUserMessage: string;
  adjacentTurns: ConversationMessage[];
  semanticEvidence: {
    status: "sufficient" | "insufficient";
    source: "current_user_message" | "established_conversation_frame" | "none";
    reason: string;
  };
  activeAnswerFrame: { type: string | null; question: string | null; compatible: boolean };
  interaction: ConversationInteractionSignals;
  evidenceSignals: {
    explicitAdviceRequest: boolean;
  };
  repairSignal: boolean;
  correction: CorrectionSignal | null;
  grounding: AssistantGrounding;
  confirmedFacts: string[];
  unconfirmedHypotheses: string[];
  safety: { level: "low" | "crisis"; triggered: boolean; reason?: string };
};

export type AnswerObligation = {
  id: string;
  sourceConversationId: string;
  sourceTurnId: string;
  triggeringUserAct: DialogueAct;
  targetProposition: string;
  status: "open" | "answered" | "withdrawn" | "expired";
  closeReason?: "response_committed" | "user_withdrew" | "thread_closed" | "superseded";
  question: string;
  kind: DirectQuestionKind;
  priority: "must_answer_first";
  requiredDisclosure: string[];
  evidence: string[];
};

export type CommonGroundProposition = {
  id: string;
  text: string;
  status: "confirmed" | "hypothesized" | "rejected";
  subject: "user" | "assistant" | "system" | "conversation";
  speaker: "user" | "assistant" | "system";
  epistemicStatus:
    | "asserted_by_user"
    | "assistant_hypothesis"
    | "system_truth"
    | "selected_memory"
    | "rejected_by_user";
  sourceTurnId: string;
  confidence: number;
  evidence: string[];
};

export type InteractionState = {
  currentActivity: {
    primary:
      | "answering_obligation"
      | "repairing_common_ground"
      | "developing_thread"
      | "opening_thread"
      | "supporting_emotion"
      | "supporting_action"
      | "pausing"
      | "idle"
      | "ordinary_exchange";
    concurrent: Array<
      | "answering_obligation"
      | "repairing_common_ground"
      | "developing_thread"
      | "opening_thread"
      | "supporting_emotion"
      | "supporting_action"
      | "pausing"
      | "idle"
      | "ordinary_exchange"
    >;
    evidence: string[];
  };
  activeThread: {
    id: string;
    sourceTurnIds: string[];
    status: "active" | "paused" | "closed";
    evidence: string[];
  } | null;
  commonGround: {
    confirmed: CommonGroundProposition[];
    hypothesized: CommonGroundProposition[];
    rejected: CommonGroundProposition[];
  };
  openObligations: AnswerObligation[];
  initiativeOwner: "user" | "assistant" | "shared" | "paused";
  lastCommittedAssistantMove: CommittedAssistantMove | null;
  repairState: {
    status: "none" | "active" | "resolved";
    targetTurnId?: string;
    rejectedPropositionIds: string[];
    evidence: string[];
  };
};

export type DialogueState = InteractionState & {
  /** Compatibility trace fields. They are projections, not Planner inputs. */
  openLoops: string[];
  answerObligations: AnswerObligation[];
  currentInitiative: ConversationInteractionSignals["initiativeDirection"];
  correction: CorrectionSignal | null;
  conversationContinuity: {
    relation: "responds_to_invitation" | "follows_previous_wording" | "continues_topic" | "new_topic";
    evidence: string[];
  };
  confirmedFacts: string[];
  unconfirmedHypotheses: string[];
  activeInteractionNeeds: Array<"direct_answer" | "explanation" | "ordinary_interaction" | "emotional_support" | "action_support" | "pause" | "repair">;
};

export type ClinicalStrategyAdvice = {
  strategy: string;
  intent: string;
  questionFunction: string;
  toneConstraints: string[];
  interventionBoundaries: string[];
  evidence: string[];
};

export type ResponseAction =
  | "answer_directly" | "explain_plainly" | "repair_previous_wording"
  | "acknowledge_without_psychologizing" | "respond_to_proactive_greeting"
  | "take_light_topic_initiative"
  | "offer_emotional_support" | "offer_action_support" | "respect_pause";

export type ResponsePlan = {
  planId: string;
  decisionOwner: "conversation_os.response_planner";
  planningDepth: "minimal" | "standard" | "deep";
  answerObligations: AnswerObligation[];
  disclosureScope: { conversationId: string; turnId: string };
  correction: CorrectionSignal | null;
  responseActions: ResponseAction[];
  groundingFacts: string[];
  requiredDisclosure: string[];
  clinicalStrategy: ClinicalStrategyAdvice | null;
  questionPolicy: { mode: "none" | "optional_after_answer" | "one_low_pressure_question"; reason: string };
  closurePolicy: { mode: "forbid_closure" | "allow_pause" | "allow_idle" | "end_conversation"; reason: string };
  tone: string[];
  stance: string[];
  lengthGuidance: string;
  prohibitedClaims: string[];
  safetyConstraints: string[];
  relevanceProvenance: Array<{
    planElement: string;
    source: "current_turn" | "adjacent_turn" | "interaction_state" | "system_truth" | "safety";
    sourceTurnId?: string;
    evidence: string[];
  }>;
  evidence: string[];
};

export type ResponseValidationResult = { passed: boolean; failureReasons: string[]; checkedPlanId: string; planChanged: false };

export type ConversationControlTrace = {
  context: ConversationControlContext;
  interpretation: TurnInterpretation;
  interpretationModel: {
    attempted: boolean;
    used: boolean;
    reason: string;
    model?: string;
    latencyMs?: number;
    tokenInput?: number;
    tokenOutput?: number;
    promptMessages?: Array<{ role: "developer" | "user" | "assistant"; content: string }>;
    rawOutput?: string;
    error?: string;
  };
  dialogueState: DialogueState;
  responsePlan: ResponsePlan;
  clinicalInvoked: boolean;
  validation: ResponseValidationResult[];
  stateUpdate: {
    answeredObligations: string[];
    remainingOpenLoops: string[];
    obligationTransitions: Array<{
      id: string;
      from: "open";
      to: "answered" | "withdrawn" | "expired";
      closeReason: NonNullable<AnswerObligation["closeReason"]>;
      sourceConversationId: string;
      sourceTurnId: string;
    }>;
    notes: string[];
  };
};
