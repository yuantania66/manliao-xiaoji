import type {
  ClinicalStrategyAdvice,
  ConversationControlContext,
  DialogueState,
  ResponseAction,
  ResponsePlan,
  TurnInterpretation,
} from "./types";
import { isProactiveGreetingPromptVersion } from "@/lib/proactive-greeting";

export type ClinicalAdviceProvider = (input: {
  need: "emotional_support" | "action_support";
  context: ConversationControlContext;
  interpretation: TurnInterpretation;
}) => ClinicalStrategyAdvice | null;

const unique = <T>(items: T[]) => Array.from(new Set(items));

const hasActivity = (
  state: DialogueState,
  activity: DialogueState["currentActivity"]["primary"]
) => state.currentActivity.primary === activity ||
  state.currentActivity.concurrent.includes(activity);

const actionsForState = ({
  state,
  respondsToProactiveGreeting,
}: {
  state: DialogueState;
  respondsToProactiveGreeting: boolean;
}): ResponseAction[] => {
  const actions: ResponseAction[] = [];
  if (hasActivity(state, "pausing")) return ["respect_pause"];
  if (hasActivity(state, "answering_obligation")) actions.push("answer_directly");
  if (state.openObligations.some((obligation) =>
    obligation.kind === "definition" || obligation.kind === "reason_or_contradiction"
  )) actions.push("explain_plainly");
  if (hasActivity(state, "repairing_common_ground")) actions.push("repair_previous_wording");
  if (hasActivity(state, "supporting_action")) actions.push("offer_action_support");
  if (hasActivity(state, "supporting_emotion")) actions.push("offer_emotional_support");
  if (
    !hasActivity(state, "supporting_emotion") &&
    !hasActivity(state, "supporting_action") &&
    !hasActivity(state, "answering_obligation") &&
    (
      hasActivity(state, "opening_thread") ||
      (hasActivity(state, "repairing_common_ground") && state.initiativeOwner === "assistant")
    )
  ) actions.push("take_light_topic_initiative");
  if (actions.length === 0) {
    actions.push(
      respondsToProactiveGreeting
        ? "respond_to_proactive_greeting"
        : "acknowledge_without_psychologizing"
    );
  }
  return unique(actions);
};

const actionEvidence = (
  action: ResponseAction,
  state: DialogueState,
  context: ConversationControlContext
): string[] => {
  const currentTurnEvidence = [`currentUserMessage=${context.currentUserMessage}`];
  if (action === "answer_directly") {
    return [
      ...currentTurnEvidence,
      ...state.openObligations.flatMap((obligation) => [
        `openObligation=${obligation.id}`,
        ...obligation.evidence,
      ]),
    ];
  }
  if (action === "repair_previous_wording") {
    return [...currentTurnEvidence, ...state.repairState.evidence];
  }
  if (action === "respect_pause") {
    return [...currentTurnEvidence, ...(state.activeThread?.evidence ?? ["initiativeOwner=paused"])];
  }
  if (action === "take_light_topic_initiative") {
    return [
      ...currentTurnEvidence,
      `initiativeOwner=${state.initiativeOwner}`,
      ...(state.activeThread?.evidence ?? []),
    ];
  }
  return [
    ...currentTurnEvidence,
    `currentActivity=${state.currentActivity.primary}`,
    ...state.currentActivity.concurrent.map((item) => `concurrentActivity=${item}`),
    ...(state.activeThread?.evidence ?? []),
  ];
};

export const createResponsePlan = ({
  context,
  interpretation,
  dialogueState,
  clinicalAdviceProvider,
}: {
  context: ConversationControlContext;
  interpretation: TurnInterpretation;
  dialogueState: DialogueState;
  clinicalAdviceProvider: ClinicalAdviceProvider;
}): ResponsePlan => {
  const lastAssistantTurn = [...context.adjacentTurns]
    .reverse()
    .find((turn) => turn.role === "assistant");
  const respondsToProactiveGreeting = Boolean(
    lastAssistantTurn &&
    context.adjacentTurns.at(-1)?.role === "assistant" &&
    isProactiveGreetingPromptVersion(lastAssistantTurn.promptVersion)
  );
  const preProactiveGreetingUserMessages = respondsToProactiveGreeting
    ? context.adjacentTurns
        .slice(0, -1)
        .filter((turn) => turn.role === "user")
        .slice(-4)
        .map((turn) => turn.content)
    : [];
  const actions = actionsForState({ state: dialogueState, respondsToProactiveGreeting });
  const clinicalNeed = hasActivity(dialogueState, "supporting_action")
    ? "action_support"
    : hasActivity(dialogueState, "supporting_emotion")
      ? "emotional_support"
      : null;
  const clinicalStrategy = clinicalNeed
    ? clinicalAdviceProvider({ need: clinicalNeed, context, interpretation })
    : null;
  const requiredDisclosure = unique(
    dialogueState.openObligations.flatMap((item) => item.requiredDisclosure)
  );
  const groundingFacts = dialogueState.commonGround.confirmed
    .map((item) => item.text)
    .filter((fact) => fact.startsWith("Selected user-confirmed memory:"));
  const simpleDirectAnswer =
    hasActivity(dialogueState, "answering_obligation") && !clinicalNeed;
  const repairsAssistant = hasActivity(dialogueState, "repairing_common_ground");
  const takesTopicInitiative = actions.includes("take_light_topic_initiative");
  const answersAssistantQuestion =
    dialogueState.lastCommittedAssistantMove?.questionOrRequest?.kind === "question" &&
    dialogueState.lastCommittedAssistantMove.expectedUserContribution === "answer" &&
    !takesTopicInitiative;
  const ordinaryChat = !clinicalNeed;
  const structurallyComplexConcurrent = dialogueState.currentActivity.concurrent.filter(
    (activity) => activity !== "developing_thread" && activity !== "ordinary_exchange"
  );
  const planningDepth: ResponsePlan["planningDepth"] =
    context.safety.triggered ||
    Boolean(clinicalNeed) ||
    hasActivity(dialogueState, "repairing_common_ground") ||
    interpretation.responseRelation.ambiguous
      ? "deep"
      : dialogueState.openObligations.length > 0 ||
          structurallyComplexConcurrent.length > 0
        ? "standard"
        : "minimal";
  const idle = hasActivity(dialogueState, "idle");
  const questionMode = hasActivity(dialogueState, "pausing") ||
    idle ||
    simpleDirectAnswer ||
    (repairsAssistant && !takesTopicInitiative) ||
    answersAssistantQuestion
    ? "none"
    : respondsToProactiveGreeting
      ? "optional_after_answer"
      : dialogueState.initiativeOwner === "shared"
        ? "none"
        : takesTopicInitiative
          ? "one_low_pressure_question"
          : "optional_after_answer";
  const relevanceProvenance: ResponsePlan["relevanceProvenance"] = [
    ...actions.map((action) => ({
      planElement: `responseAction:${action}`,
      source: "interaction_state" as const,
      sourceTurnId: context.currentTurnId,
      evidence: actionEvidence(action, dialogueState, context),
    })),
    ...dialogueState.openObligations.map((obligation) => ({
      planElement: `answerObligation:${obligation.id}`,
      source: "current_turn" as const,
      sourceTurnId: obligation.sourceTurnId,
      evidence: obligation.evidence,
    })),
    ...requiredDisclosure.map((disclosure) => ({
      planElement: `requiredDisclosure:${disclosure}`,
      source: "system_truth" as const,
      sourceTurnId: context.currentTurnId,
      evidence: dialogueState.openObligations
        .filter((obligation) => obligation.requiredDisclosure.includes(disclosure))
        .flatMap((obligation) => [`requiredBy=${obligation.id}`, ...obligation.evidence]),
    })),
    ...groundingFacts.map((fact) => ({
      planElement: `groundingFact:${fact}`,
      source: "interaction_state" as const,
      sourceTurnId: dialogueState.commonGround.confirmed.find((item) => item.text === fact)?.sourceTurnId,
      evidence: dialogueState.commonGround.confirmed.find((item) => item.text === fact)?.evidence ?? [],
    })),
  ];

  return {
    planId: `${context.conversationId}:${context.currentTurnId}:response-plan`,
    decisionOwner: "conversation_os.response_planner",
    planningDepth,
    answerObligations: dialogueState.openObligations,
    disclosureScope: {
      conversationId: context.conversationId,
      turnId: context.currentTurnId,
    },
    correction: interpretation.correction,
    responseActions: actions,
    groundingFacts,
    requiredDisclosure,
    clinicalStrategy,
    questionPolicy: {
      mode: questionMode,
      reason: hasActivity(dialogueState, "pausing")
        ? "Interaction State is paused."
        : simpleDirectAnswer
          ? "The current open obligation must be answered without adding another obligation."
          : answersAssistantQuestion
            ? "The current turn answers the assistant's question, including a question used as a proactive greeting; do not open a second interview question."
            : respondsToProactiveGreeting
              ? "The user responded to a non-question proactive greeting; one specific natural follow-up is optional, but an interview loop is not."
              : repairsAssistant && !takesTopicInitiative
                ? "Repair the rejected common-ground proposition without opening a new interview loop."
                : repairsAssistant
                  ? "Repair the rejected proposition, then return initiative according to the still-active thread."
                  : dialogueState.initiativeOwner === "shared"
                    ? "Initiative is shared; do not force another question."
                    : takesTopicInitiative
                      ? "Interaction State assigns topic initiative to the assistant."
                      : "A follow-up is optional only after the current activity is completed.",
    },
    closurePolicy: {
      mode: hasActivity(dialogueState, "pausing")
        ? "allow_pause"
        : idle
          ? "allow_idle"
          : "forbid_closure",
      reason: hasActivity(dialogueState, "pausing")
        ? "Interaction State contains explicit pause evidence."
        : idle
          ? "The committed interaction can settle without forcing a new topic."
        : "Interaction State contains no accepted stop transition.",
    },
    tone: ordinaryChat
      ? ["natural colloquial Chinese", "direct", "neutral-friendly without reassurance"]
      : ["natural Chinese", "direct", "warm without counselling jargon"],
    stance: [
      "Realize only propositions and actions present in this ResponsePlan.",
      "Do not promote hypotheses into common ground.",
      "Do not restate propositions rejected by the user.",
    ],
    lengthGuidance: simpleDirectAnswer
      ? "Usually one concise sentence; at most two."
      : "Usually one or two concise sentences.",
    prohibitedClaims: unique([
      ...context.grounding.prohibitedClaims,
      ...dialogueState.commonGround.rejected.map((item) =>
        `Do not assert, explain, or expand rejected proposition: ${item.text}`
      ),
      "不得在没有证据时断言用户的情绪、意图或心理状态。",
      ...(context.semanticEvidence.status === "insufficient"
        ? ["Do not infer meaning from message form or repetition."]
        : []),
    ]),
    safetyConstraints: context.safety.triggered
      ? [context.safety.reason ?? "Safety override applies."]
      : [],
    relevanceProvenance,
    evidence: unique([
      `currentActivity=${dialogueState.currentActivity.primary}`,
      `planningDepth=${planningDepth}`,
      ...dialogueState.currentActivity.concurrent.map((item) => `concurrentActivity=${item}`),
      `initiativeOwner=${dialogueState.initiativeOwner}`,
      `openObligations=${dialogueState.openObligations.length}`,
      `clinicalInvoked=${Boolean(clinicalStrategy)}`,
      ...preProactiveGreetingUserMessages.map(
        (content) => `preProactiveGreetingUserMessage=${content}`
      ),
      ...(dialogueState.activeThread?.evidence ?? []),
      ...dialogueState.repairState.evidence,
    ]),
  };
};
