import type { ResponsePlan, ResponseValidationResult } from "@/conversation-os/control";
import { explicitlyResumesPreGreetingHistory } from "@/lib/proactive-greeting";

import { collectUnsupportedMeaningFailureReasons } from "./semanticEvidenceReplyGuard";
import type { AiGenerationResult } from "./types";

const normalize = (value: string) => value.replace(/\s+/g, " ").trim();
const normalizeForEcho = (value: string) =>
  value
    .replace(/[\s，。！？、,.!?：:；;“”"'‘’（）()…—-]/gu, "")
    .replace(/^(?:嗯|哦|啊|呀|诶|原来是)/u, "")
    .replace(/(?:啊|呀|呢|哦)$/u, "")
    .trim();

const currentUserMessageFromPlan = (plan: ResponsePlan) => {
  const prefix = "currentUserMessage=";
  for (const provenance of plan.relevanceProvenance) {
    const evidence = provenance.evidence.find((item) => item.startsWith(prefix));
    if (evidence) return normalize(evidence.slice(prefix.length));
  }
  return "";
};

const preProactiveGreetingUserMessagesFromPlan = (plan: ResponsePlan) => {
  const prefix = "preProactiveGreetingUserMessage=";
  return plan.evidence
    .filter((item) => item.startsWith(prefix))
    .map((item) => normalize(item.slice(prefix.length)))
    .filter(Boolean);
};

const unsupportedEvaluationTerms = [
  "热闹",
  "棒",
  "挺好",
  "很好",
  "不错",
  "难得",
  "珍贵",
  "舒服",
  "放松",
  "开心",
  "有趣",
  "好玩",
  "投入",
];

const collectOrdinaryAcknowledgementFailures = ({
  plan,
  reply,
}: {
  plan: ResponsePlan;
  reply: string;
}) => {
  if (!plan.responseActions.includes("acknowledge_without_psychologizing")) return [];
  const userMessage = currentUserMessageFromPlan(plan);
  const failures: string[] = [];
  if (
    /(?:这种|这样的|现场|氛围).{0,16}(?:容易|会让|让人|能让).{0,16}(?:投入|放松|开心|舒服|沉浸|忘记)/u.test(reply)
  ) {
    failures.push("ordinary_acknowledgement:generic_causal_mechanism");
  }
  if (userMessage) {
    const addedEvaluation = unsupportedEvaluationTerms.find((term) =>
      reply.includes(term) && !userMessage.includes(term)
    );
    if (addedEvaluation) {
      failures.push(`ordinary_acknowledgement:unsupported_evaluation:${addedEvaluation}`);
    }
  }
  return failures;
};

const collectTopicInitiativeFailures = ({
  plan,
  reply,
}: {
  plan: ResponsePlan;
  reply: string;
}) => {
  if (!plan.responseActions.includes("take_light_topic_initiative")) return [];
  const failures: string[] = [];
  if (
    /^(?:没关系|不要紧|不用着急|不想说(?:也)?(?:可以|没关系|就不说)|先不说(?:也行)?)[，,。！!\s]*/u.test(reply)
  ) {
    failures.push("topic_initiative:reassurance_or_pause_preface");
  }
  if (/(?:让你觉得|有没有什么小事).{0,10}(?:还行|不错|开心|舒服|治愈|感激)/u.test(reply)) {
    failures.push("topic_initiative:positive_or_healing_frame");
  }
  return failures;
};

const collectProactiveGreetingResponseFailures = ({
  plan,
  reply,
}: {
  plan: ResponsePlan;
  reply: string;
}) => {
  if (!plan.responseActions.includes("respond_to_proactive_greeting")) return [];
  const userMessage = currentUserMessageFromPlan(plan);
  const failures: string[] = [];
  if (
    /^(?:嗯|哦|好|好的|知道了|收到|明白了|行)[，,。！!\s]*(?:知道了|收到|明白了)?[。！!\s]*$/u.test(reply)
  ) {
    failures.push("proactive_greeting_response:empty_acknowledgement");
  }
  if (/(?:就好|就行|就可以了|知道了|收到(?:了)?)[。！!\s]*$/u.test(reply)) {
    failures.push("proactive_greeting_response:generic_closure");
  }
  if (/^(?:那)?(?:挺好|很好|不错|可以|还行)(?:的)?[。！!\s]*$/u.test(reply)) {
    failures.push("proactive_greeting_response:generic_approval");
  }
  if (userMessage) {
    const addedEvaluation = unsupportedEvaluationTerms.find((term) =>
      reply.includes(term) && !userMessage.includes(term)
    );
    if (addedEvaluation) {
      failures.push(
        `proactive_greeting_response:unsupported_evaluation:${addedEvaluation}`
      );
    }
  }
  const normalizedReply = normalizeForEcho(reply);
  const normalizedUser = normalizeForEcho(userMessage);
  if (
    normalizedReply &&
    normalizedUser &&
    (
      normalizedReply === normalizedUser ||
      (
        normalizedReply.length >= 2 &&
        normalizedUser.includes(normalizedReply)
      )
    )
  ) {
    failures.push("proactive_greeting_response:bare_echo");
  }
  if (
    /(?:还有呢|然后呢|为什么呢|想再说说吗|最近怎么样|你觉得呢)[？?]$/u.test(reply)
  ) {
    failures.push("proactive_greeting_response:generic_follow_up");
  }
  const staleContent = preProactiveGreetingUserMessagesFromPlan(plan).find(
    (message) => {
      const normalizedStale = normalizeForEcho(message);
      return (
        !explicitlyResumesPreGreetingHistory(userMessage) &&
        normalizedStale.length >= 2 &&
        normalizedReply.includes(normalizedStale) &&
        !normalizedUser.includes(normalizedStale)
      );
    }
  );
  if (staleContent) {
    failures.push("proactive_greeting_response:stale_pre_greeting_content");
  }
  return failures;
};

const repeatsRejectedGroundingProposition = (
  reply: string,
  reference: NonNullable<
    NonNullable<ResponsePlan["correction"]>["challengedPropositions"][number]["groundingReference"]
  >
) => {
  if (reference === "identity") return /慢聊小记|(?:我是|属于|作为).{0,8}(?:AI|人工智能|聊天助手)/u.test(reply);
  if (reference === "ai_identity") return /(?:我是|属于|作为).{0,8}(?:AI|人工智能|聊天助手|真人|人类)/u.test(reply);
  if (reference === "clinician_identity") return /心理医生|心理咨询师|咨询师|治疗师|专业人员/u.test(reply);
  if (["body", "body_metaphor", "physical_presence", "physical_presence_metaphor"].includes(reference)) {
    return /没有(?:真实)?身体|没有现实中的物理位置|不能真的|不会真的|没法真的|不是字面|只是.{0,8}(?:说法|比喻|比方)/u.test(reply);
  }
  if (reference === "voice_input" || reference === "hearing") return /语音输入|不能听|听不见|只能.{0,4}文字/u.test(reply);
  if (reference === "voice_output") return /语音输出|不能.{0,6}(?:发|播放|用).{0,4}语音|只能.{0,4}(?:文字|打字)/u.test(reply);
  if (reference === "vision") return /不能看|看不见|看不到|没法看|无法看/u.test(reply);
  if (reference === "time") return /实时|当前时间|现在几点/u.test(reply);
  if (reference === "memory") return /记忆|记得|不一定记得/u.test(reply);
  return false;
};

const obligationSatisfied = (reply: string, obligation: ResponsePlan["answerObligations"][number]) => {
  if (obligation.kind === "identity") {
    return /慢聊小记/u.test(reply) && /AI|人工智能|聊天助手/u.test(reply);
  }
  if (obligation.kind === "ai_identity") {
    const statesAiIdentity = /AI|人工智能|聊天助手/u.test(reply);
    const contradictsHumanClaim = /(?:我是|属于|作为).{0,6}(?:真人|人类)/u.test(reply);
    return statesAiIdentity && !contradictsHumanClaim;
  }
  if (obligation.kind === "clinician_identity") {
    return /不是|不能代替|不能替代|不属于/u.test(reply) &&
      /心理医生|心理咨询师|咨询师|治疗师|专业人员/u.test(reply);
  }
  if (obligation.kind === "body_capability") {
    const statesLiteralBoundary = /没有(?:真实)?身体|没有现实中的物理位置|不能真的|不会真的|没法真的|不是字面|只是.{0,8}(?:说法|比喻|比方)|通过文字/u.test(reply);
    const requiresMetaphorAcknowledgement = obligation.requiredDisclosure.some((item) =>
      item.includes("关系隐喻")
    );
    const acknowledgesMetaphor = /(?:刚才|前面|上一句|之前).{0,12}(?:说法|比喻|比方|口语)|只是.{0,8}(?:说法|比喻|比方)/u.test(reply);
    return statesLiteralBoundary && (!requiresMetaphorAcknowledgement || acknowledgesMetaphor);
  }
  if (obligation.kind === "voice_input") return /不能听|听不见|不支持.{0,4}语音输入|只能.{0,4}文字/u.test(reply);
  if (obligation.kind === "voice_output") return /不能.{0,6}(?:发|播放|用).{0,4}语音|不支持.{0,4}语音|只能.{0,4}(?:文字|打字)|文字.{0,6}(?:回复|聊天|交流)/u.test(reply);
  if (obligation.kind === "perception_capability") return /不能看|看不见|看不到|没法看|无法看|只能.{0,4}文字/u.test(reply);
  if (obligation.kind === "time_capability") return /不知道.{0,6}(?:实时|当前|现在).{0,4}时间|没有.{0,6}(?:实时|当前).{0,4}时间|需要.{0,6}(?:提供|告诉).{0,4}时间/u.test(reply);
  if (obligation.kind === "memory_capability") return /只能.{0,12}(?:当前|提供|选取|聊天)|不一定记得|不会.{0,8}全部|有限/u.test(reply);
  if (obligation.kind === "definition") return /意思是|指的是|是指|说的是|就是说|就是/u.test(reply) && !/^[^。！!]{0,30}[？?]$/u.test(reply);
  if (obligation.kind === "reason_or_contradiction") return /因为|其实|刚才|我说的|只能|文字|指的是/u.test(reply) && !/^[^。！!]{0,30}[？?]$/u.test(reply);
  return Boolean(reply) && !/^[^。！!]{0,30}[？?]$/u.test(reply);
};

export const validateResponsePlanOutput = ({ plan, reply }: { plan: ResponsePlan; reply: string }): ResponseValidationResult => {
  const text = normalize(reply);
  const failureReasons: string[] = [];
  for (const obligation of plan.answerObligations) {
    if (!obligationSatisfied(text, obligation)) failureReasons.push(`unanswered_obligation:${obligation.id}:${obligation.kind}`);
  }
  if (plan.questionPolicy.mode === "none" && /[？?]/u.test(text)) {
    failureReasons.push("question_not_allowed_by_plan");
  }
  if ((text.match(/[？?]/gu) ?? []).length > 1) {
    failureReasons.push("too_many_follow_up_questions");
  }
  if (plan.closurePolicy.mode === "forbid_closure" && /就(?:先)?这样(?:安静地?)?待着|安静(?:地)?待着也|先不说也行|不聊也行|停在这里|先放在这里/u.test(text)) {
    failureReasons.push("premature_closure");
  }
  if (plan.responseActions.includes("take_light_topic_initiative")) {
    if (!/[？?]/u.test(text) && !/(?:我来|聊个|先从|起个头|说个|换个轻松)/u.test(text)) {
      failureReasons.push("missing_light_topic_initiative");
    }
    if (/(?:你)?(?:想|要不要)?(?:聊|说)(?:点)?什么|从哪里(?:开始|说起)|想不到(?:也)?没关系/u.test(text)) {
      failureReasons.push("initiative_returned_to_user");
    }
  }
  failureReasons.push(...collectOrdinaryAcknowledgementFailures({ plan, reply: text }));
  failureReasons.push(...collectTopicInitiativeFailures({ plan, reply: text }));
  failureReasons.push(...collectProactiveGreetingResponseFailures({ plan, reply: text }));
  for (const proposition of plan.correction?.challengedPropositions ?? []) {
    if (
      proposition.groundingReference &&
      repeatsRejectedGroundingProposition(text, proposition.groundingReference)
    ) {
      failureReasons.push(`repeated_rejected_grounding_proposition:${proposition.id}`);
    }
  }
  if (/(?:我会|我能|我可以).{0,5}(?:真的)?(?:坐|抱|触碰)|我(?:就在|正待在).{0,8}(?:你身边|这里陪你)/u.test(text)) {
    failureReasons.push("assistant_grounding:embodiment_claim");
  }
  if (/(?:我是|属于|作为).{0,6}(?:心理医生|心理咨询师|治疗师)/u.test(text)) {
    failureReasons.push("assistant_grounding:clinician_claim");
  }
  if (/(?:我是|属于|作为).{0,6}(?:真人|人类)/u.test(text)) {
    failureReasons.push("assistant_grounding:human_claim");
  }
  if (/(?:我能|我可以|我会|我正在|我就在).{0,8}(?:看见|看到|听见|听到|触碰|碰到|抱到)/u.test(text)) {
    failureReasons.push("assistant_grounding:unsupported_perception_or_contact");
  }
  if (plan.prohibitedClaims.some((claim) => claim.includes("message form or repetition"))) {
    failureReasons.push(...collectUnsupportedMeaningFailureReasons(text));
  }
  return {
    passed: failureReasons.length === 0,
    failureReasons: Array.from(new Set(failureReasons)),
    checkedPlanId: plan.planId,
    planChanged: false,
  };
};

const regenerationInstructionFor = (failure: string) => {
  const unsupportedEvaluation = failure.match(
    /^(?:ordinary_acknowledgement|proactive_greeting_response):unsupported_evaluation:(.+)$/u
  );
  if (unsupportedEvaluation) {
    const term = unsupportedEvaluation[1];
    return `删掉助手自行添加的评价词“${term}”。用户没有评价该活动、偏好或经历时，不要替用户说它好、不错、舒服或有益；只承接用户明确说出的内容。`;
  }
  if (failure === "proactive_greeting_response:stale_pre_greeting_content") {
    return "删除主动欢迎语之前的旧话题。只回应当前用户在欢迎语之后明确说出的内容；除非用户本轮主动重提，否则不要恢复更早的话题。";
  }
  return `修复校验项 ${failure}，不要改变 ResponsePlan 的动作、事实边界或对话目标。`;
};

export const formatResponsePlanRegenerateConstraint = (
  plan: ResponsePlan,
  failures: string[]
) => [
  "上一次候选回复未通过同一 ResponsePlan 的输出校验。",
  `必须保持完全相同的 ResponsePlan planId=${plan.planId}；不得重新解释用户，不得另选目标或策略。`,
  "本次只按以下要求改写：",
  ...failures.map((failure) =>
    `- failureCode=${failure}\n  修复方式：${regenerationInstructionFor(failure)}`
  ),
  ...(plan.questionPolicy.mode === "none"
    ? ["- 本计划禁止提问：不要添加问号，不要换一个话题继续采访用户。"]
    : []),
  "不要输出错误码、校验说明或内部计划；只输出新的用户可见回复。",
].join("\n");

const constraintFailureGeneration = (
  first: AiGenerationResult,
  second: AiGenerationResult,
  failures: string[]
): AiGenerationResult => ({
  ...second,
  rawLLMOutput: second.rawLLMOutput ?? second.text,
  finalReplySource: "constraint_failure",
  postProcessSteps: [
    ...(first.postProcessSteps ?? []),
    {
      layer: "response_plan_output_validation",
      before: first.rawLLMOutput ?? first.text,
      after: second.rawLLMOutput ?? second.text,
      reason: "Regenerated once against the same ResponsePlan after the first validation failure.",
    },
    ...(second.postProcessSteps ?? []),
    {
      layer: "response_plan_output_validation",
      before: second.rawLLMOutput ?? second.text,
      after: second.rawLLMOutput ?? second.text,
      reason: `Same ResponsePlan failed twice and remained an internal rejected candidate: ${failures.join(", ")}`,
    },
  ],
});

export const enforceResponsePlan = async ({
  plan,
  generate,
}: {
  plan: ResponsePlan;
  generate: (constraint: string | null) => Promise<AiGenerationResult>;
}) => {
  const first = await generate(null);
  const firstValidation = validateResponsePlanOutput({ plan, reply: first.text });
  if (firstValidation.passed) {
    return {
      outcome: "validated" as const,
      generation: first,
      attempts: [first],
      validations: [firstValidation],
      regenerateAttempted: false,
    };
  }
  const second = await generate(formatResponsePlanRegenerateConstraint(plan, firstValidation.failureReasons));
  const secondValidation = validateResponsePlanOutput({ plan, reply: second.text });
  if (secondValidation.passed) {
    return {
      outcome: "validated" as const,
      generation: {
        ...second,
        finalReplySource: "llm_regenerate" as const,
        postProcessSteps: [
          ...(first.postProcessSteps ?? []),
          {
            layer: "response_plan_output_validation",
            before: first.text,
            after: second.text,
            reason: `Regenerated against the same plan after: ${firstValidation.failureReasons.join(", ")}`,
          },
          ...(second.postProcessSteps ?? []),
        ],
      },
      attempts: [first, second],
      validations: [firstValidation, secondValidation],
      regenerateAttempted: true,
    };
  }
  return {
    outcome: "failed" as const,
    generation: constraintFailureGeneration(first, second, [...firstValidation.failureReasons, ...secondValidation.failureReasons]),
    attempts: [first, second],
    validations: [firstValidation, secondValidation],
    regenerateAttempted: true,
  };
};
