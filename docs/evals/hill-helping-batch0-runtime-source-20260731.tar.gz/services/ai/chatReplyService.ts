import {
  AiGenerationStatus,
  AiRiskLevel as PrismaAiRiskLevel,
  AiSourceType,
  MessageRole,
  MessageStatus,
  Prisma,
} from "@prisma/client";

import { prisma } from "@/lib/prisma";

import { createChatReply } from "./chatOrchestrationService";
import { createChatMemoryContext, createNoteMemoryContext } from "./dataLayers";
import {
  AiConversationMessage,
  AiDebugTrace,
  AiGenerationResult,
  AiJudgeResult,
  AiMemoryContext,
  AiRiskLevel,
} from "./types";
import { createRawMemoryFromChatMessage } from "@/services/memory/rawMemoryService";
import { StructuredRagContext } from "@/services/understanding/understandingTypes";
import {
  toUserSafeExecutionStatus,
  type ChatExecutionTrace,
  type UserSafeExecutionStatus,
} from "./chatExecutionLifecycle";
import type { InteractionState } from "@/conversation-os/control";

const mapRiskLevel = (riskLevel: AiRiskLevel) => {
  const value = riskLevel.toUpperCase();
  if (value === "MEDIUM" || value === "HIGH" || value === "CRISIS") {
    return value as PrismaAiRiskLevel;
  }
  return PrismaAiRiskLevel.LOW;
};

const isStableMemoryText = (value: string) =>
  value.trim().length >= 6 && !/^([0-9０-９]+|[a-zA-Z]|[嗯啊哦好行对是])$/.test(value.trim());

const previewMemory = (value: string) => value.replace(/\s+/g, " ").trim().slice(0, 48);

const loadMemoryContext = async ({
  userId,
  sessionId,
}: {
  userId: string;
  sessionId: string;
}): Promise<AiMemoryContext | null> => {
  const note = await prisma.note.findFirst({
    where: { userId },
    orderBy: [{ recordDate: "desc" }, { createdAt: "desc" }],
    select: {
      content: true,
      recordDate: true,
    },
  });

  if (note && isStableMemoryText(note.content)) {
    return createNoteMemoryContext({
      text: previewMemory(note.content),
      date: note.recordDate.toISOString().slice(0, 10),
    });
  }

  const chatMessage = await prisma.chatMessage.findFirst({
    where: {
      userId,
      sessionId: { not: sessionId },
      role: MessageRole.USER,
    },
    orderBy: { createdAt: "desc" },
    select: {
      content: true,
      createdAt: true,
    },
  });

  if (chatMessage && isStableMemoryText(chatMessage.content)) {
    return createChatMemoryContext({
      text: previewMemory(chatMessage.content),
      date: chatMessage.createdAt.toISOString().slice(0, 10),
    });
  }

  return null;
};

const serializeMessage = (message: {
  id: string;
  role: MessageRole;
  content: string;
  status: MessageStatus;
  aiGenerationId: string | null;
  aiGeneration?: { promptVersion: string } | null;
  createdAt: Date;
}) => ({
  id: message.id,
  role: message.role.toLowerCase(),
  content: message.content,
  status: message.status.toLowerCase(),
  aiGenerationId: message.aiGenerationId,
  promptVersion: message.aiGeneration?.promptVersion ?? null,
  createdAt: message.createdAt.toISOString(),
});

const saveGeneration = async ({
  userId,
  sessionId,
  inputText,
  generation,
  status,
  rewriteOfId,
  execution,
  attemptId,
  turnId,
}: {
  userId: string;
  sessionId: string;
  inputText: string;
  generation: AiGenerationResult;
  status: AiGenerationStatus;
  rewriteOfId?: string;
  execution: ChatExecutionTrace;
  attemptId?: string;
  turnId: string;
}) =>
  prisma.aiGeneration.create({
    data: {
      userId,
      sessionId,
      sourceType: AiSourceType.CHAT,
      sourceId: turnId,
      model: generation.model,
      promptVersion: generation.promptVersion,
      inputText,
      outputText: generation.text,
      rewriteOfId,
      requestId: execution.requestId,
      turnId,
      attemptId,
      executionTrace: execution as unknown as Prisma.InputJsonValue,
      latencyMs: generation.latencyMs,
      tokenInput: generation.tokenInput,
      tokenOutput: generation.tokenOutput,
      status,
    },
    select: { id: true },
  });

const saveJudgeResult = async ({
  userId,
  generationId,
  judgeResult,
}: {
  userId: string;
  generationId: string;
  judgeResult: AiJudgeResult & { judgeModel: string; promptVersion: string };
}) =>
  prisma.aiJudgeResult.create({
    data: {
      userId,
      generationId,
      passed: judgeResult.passed,
      riskLevel: mapRiskLevel(judgeResult.riskLevel),
      issues: judgeResult.issues as Prisma.InputJsonValue,
      rewriteRequired: judgeResult.rewriteRequired,
      reason: judgeResult.reason,
      rawResult: (judgeResult.raw ?? null) as Prisma.InputJsonValue,
      judgeModel: judgeResult.judgeModel,
      promptVersion: judgeResult.promptVersion,
    },
    select: { id: true },
  });

export const commitValidatedAssistantMessage = async ({
  userId,
  sessionId,
  content,
  status,
  aiGenerationId,
  replyToMessageId,
  interactionMetadata,
  execution,
}: {
  userId: string;
  sessionId: string;
  content: string;
  status: MessageStatus;
  aiGenerationId: string;
  replyToMessageId: string;
  interactionMetadata: InteractionState["lastCommittedAssistantMove"];
  execution?: ChatExecutionTrace;
}) => {
  const select = {
    id: true,
    role: true,
    content: true,
    status: true,
    aiGenerationId: true,
    aiGeneration: {
      select: {
        promptVersion: true,
      },
    },
    createdAt: true,
  } satisfies Prisma.ChatMessageSelect;
  let created = false;
  const savedMessage = await prisma.$transaction(async (tx) => {
    const inserted = await tx.chatMessage.createMany({
      data: [{
        sessionId,
        userId,
        role: MessageRole.ASSISTANT,
        content,
        status,
        aiGenerationId,
        replyToMessageId,
        interactionMetadata: interactionMetadata as unknown as Prisma.InputJsonValue,
      }],
      skipDuplicates: true,
    });
    created = inserted.count === 1;
    const message = await tx.chatMessage.findUniqueOrThrow({
      where: { replyToMessageId },
      select,
    });

    if (created) {
      await tx.chatSession.update({
        where: { id: sessionId },
        data: {
          lastMessage: content,
          lastMessageAt: message.createdAt,
        },
      });
    }
    if (created && execution) {
      await tx.aiGeneration.update({
        where: { id: aiGenerationId },
        data: {
          executionTrace: {
            ...execution,
            phase: "COMMITTED",
            transitions: [
              ...execution.transitions,
              {
                phase: "COMMITTED",
                reason: "Assistant Message and interaction metadata committed atomically.",
              },
            ],
            committedMessageId: message.id,
          } as unknown as Prisma.InputJsonValue,
        },
      });
    }

    return message;
  });

  if (created) {
    await createRawMemoryFromChatMessage({
      chatMessageId: savedMessage.id,
      metadata: { source: "chat_reply_service_assistant_message" },
    }).catch((error) => {
      console.error("raw memory assistant message write failed", error);
    });
  }

  return savedMessage;
};

export const buildCommittedAssistantMove = (
  reply: Awaited<ReturnType<typeof createChatReply>>
): NonNullable<InteractionState["lastCommittedAssistantMove"]> => {
  const plan = reply.controlTrace?.responsePlan;
  const question = Boolean(
    plan &&
    plan.questionPolicy.mode !== "none" &&
    /[？?]/u.test(reply.generation.text)
  );
  return {
    purpose: plan?.responseActions ?? [],
    claims: [
      ...(plan?.groundingFacts ?? []),
      ...(plan?.requiredDisclosure ?? []),
    ].map((text) => ({
      text,
      subject: plan?.requiredDisclosure.includes(text) ? "assistant" as const : "user" as const,
      source: plan?.relevanceProvenance.find((item) => item.planElement.endsWith(text))?.source,
      provenance: plan?.relevanceProvenance
        .filter((item) => item.planElement.endsWith(text))
        .flatMap((item) => item.evidence) ?? [],
    })),
    assumptions: [],
    questionOrRequest: question ? { kind: "question" } : null,
    expectedUserContribution: question
      ? plan?.responseActions.includes("take_light_topic_initiative")
        ? "share"
        : "answer"
      : "none",
    userBurden: question ? "low" : "none",
    sourceTurnId: reply.execution.turnId,
    evidence: [
      `planId=${reply.execution.planId}`,
      `requestId=${reply.execution.requestId}`,
      "Created only after the validated Assistant Message committed.",
    ],
  };
};

const markCommitted = (
  execution: ChatExecutionTrace,
  messageId: string
): ChatExecutionTrace => ({
  ...execution,
  phase: "COMMITTED",
  transitions: [
    ...execution.transitions,
    {
      phase: "COMMITTED",
      reason: "Assistant Message and interaction metadata committed atomically.",
    },
  ],
  committedMessageId: messageId,
});

export const createReviewedChatReply = async ({
  userId,
  sessionId,
  currentTurnId,
  retrying = false,
  userMessage,
  recentMessages,
  understandingContext,
  includeDebugTrace = false,
}: {
  userId: string;
  sessionId: string;
  currentTurnId?: string;
  retrying?: boolean;
  userMessage: string;
  recentMessages: AiConversationMessage[];
  understandingContext?: StructuredRagContext | null;
  includeDebugTrace?: boolean;
}): Promise<
  | {
      outcome: "committed";
      assistantMessage: ReturnType<typeof serializeMessage>;
      judge: AiJudgeResult & { judgeModel: string; promptVersion: string };
      rewriteAttempted: boolean;
      fallbackUsed: boolean;
      debugTrace?: AiDebugTrace;
      execution: ChatExecutionTrace;
    }
  | {
      outcome: "failed";
      systemStatus: UserSafeExecutionStatus;
      debugTrace?: AiDebugTrace;
      execution: ChatExecutionTrace;
    }
> => {
  const reply = await createChatReply({
    conversationId: sessionId,
    currentTurnId,
    retrying,
    userId,
    userMessage,
    recentMessages,
    loadMemoryContext: () => loadMemoryContext({ userId, sessionId }),
    understandingContext,
    includeDebugTrace,
  });
  try {
    const attemptedGenerations = reply.generationAttempts.length
      ? reply.generationAttempts
      : [reply.generation];
    let previousGenerationId: string | undefined;
    const savedGenerations: Array<{ id: string }> = [];
    for (const [index, generation] of attemptedGenerations.entries()) {
      const accepted = reply.execution.phase === "VALIDATED" &&
        index === attemptedGenerations.length - 1;
      const saved = await saveGeneration({
        userId,
        sessionId,
        inputText: userMessage,
        generation,
        status: accepted
          ? reply.finalSource === "fallback"
            ? AiGenerationStatus.FALLBACK
            : AiGenerationStatus.GENERATED
          : AiGenerationStatus.FAILED,
        rewriteOfId: previousGenerationId,
        execution: reply.execution,
        attemptId: reply.execution.attempts[index]?.attemptId,
        turnId: reply.execution.turnId,
      });
      previousGenerationId = saved.id;
      savedGenerations.push(saved);
    }

    if (reply.execution.phase !== "VALIDATED") {
      return {
        outcome: "failed",
        systemStatus: toUserSafeExecutionStatus(reply.execution),
        debugTrace: reply.debugTrace,
        execution: reply.execution,
      };
    }

    const messageStatus = reply.finalSource === "fallback" ? MessageStatus.FALLBACK : MessageStatus.SAVED;
    const savedGeneration = savedGenerations.at(-1);
    if (!savedGeneration) throw new Error("Validated reply has no saved generation.");
    await saveJudgeResult({
      userId,
      generationId: savedGeneration.id,
      judgeResult: reply.judge,
    });
    const assistantMessage = await commitValidatedAssistantMessage({
      userId,
      sessionId,
      content: reply.generation.text,
      status: messageStatus,
      aiGenerationId: savedGeneration.id,
      replyToMessageId: reply.execution.turnId,
      interactionMetadata: buildCommittedAssistantMove(reply),
      execution: reply.execution,
    });
    const execution = markCommitted(reply.execution, assistantMessage.id);
    if (reply.controlTrace) {
      const answeredObligations = reply.controlTrace.responsePlan.answerObligations.map((item) => item.id);
      reply.controlTrace.stateUpdate = {
        answeredObligations,
        remainingOpenLoops: [],
        obligationTransitions: reply.controlTrace.responsePlan.answerObligations.map((item) => ({
          id: item.id,
          from: "open",
          to: "answered",
          closeReason: "response_committed",
          sourceConversationId: item.sourceConversationId,
          sourceTurnId: item.sourceTurnId,
        })),
        notes: ["Validated Assistant Message committed; obligation transitions are now official."],
      };
      if (reply.debugTrace) reply.debugTrace.conversationControl = reply.controlTrace;
    }
    if (reply.debugTrace) reply.debugTrace.execution = execution;

    return {
      outcome: "committed",
      assistantMessage: serializeMessage(assistantMessage),
      judge: reply.judge,
      rewriteAttempted: reply.rewriteAttempted,
      fallbackUsed: reply.fallbackUsed,
      debugTrace: reply.debugTrace,
      execution,
    };
  } catch (error) {
    const execution: ChatExecutionTrace = {
      ...reply.execution,
      phase: "FAILED",
      transitions: [
        ...reply.execution.transitions,
        {
          phase: "FAILED",
          reason: "Persistence failed before the commit boundary completed.",
        },
      ],
      failure: {
        code: "PERSISTENCE_ERROR",
        reason: error instanceof Error ? error.message : "Unknown persistence failure",
        retryable: true,
      },
      committedMessageId: undefined,
    };
    if (reply.debugTrace) reply.debugTrace.execution = execution;
    return {
      outcome: "failed",
      systemStatus: toUserSafeExecutionStatus(execution),
      debugTrace: reply.debugTrace,
      execution,
    };
  }
};
